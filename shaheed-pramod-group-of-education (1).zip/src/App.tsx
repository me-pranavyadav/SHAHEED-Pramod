import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Phone, 
  Mail, 
  MapPin, 
  MessageSquare, 
  ChevronRight, 
  Star, 
  Menu, 
  X, 
  ArrowRight, 
  GraduationCap, 
  BookOpen, 
  Users, 
  Award,
  Clock,
  CheckCircle2,
  ExternalLink,
  Upload,
  Instagram,
  Facebook,
  Twitter,
  Youtube
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import {
  Dialog,
  DialogContent,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";

// --- Constants & Data ---

const INSTITUTIONS = [
  {
    name: "SHAHEED PRAMOD B.Ed College",
    description: "Excellence in Teacher Education. NCTE Approved.",
    image: "https://i.ibb.co/wFjMW67p/photo-6266973922368622074-y.jpg",
    link: "https://shaheedpramod.in",
    badge: "NCTE Approved"
  },
  {
    name: "SHAHEED PRAMOD Higher Education",
    description: "Quality BBA, BCA, and BLIS programs for modern careers.",
    image: "https://i.ibb.co/JWybS3Yk/photo-6266973922368622077-y.jpg",
    link: "https://shaheedpramod.in",
    badge: "UGC Recognized"
  },
  {
    name: "SHAHEED PRAMOD Nursing Institute",
    description: "Compassionate care, professional training. ANM, GNM, B.Sc Nursing.",
    image: "https://i.ibb.co/BKPB5fSv/photo-6266973922368622073-y.jpg",
    link: "https://spnursing.in",
    badge: "INC Approved"
  }
];

const COURSES = [
  {
    title: "B.Ed",
    category: "Education",
    duration: "2 Years",
    eligibility: "Graduation with 50%",
    scope: "Secondary School Teacher",
    image: "https://i.ibb.co/yncYLZ4L/photo-6278394468041953204-y.jpg"
  },
  {
    title: "D.El.Ed",
    category: "Education",
    duration: "2 Years",
    eligibility: "10+2 with 50%",
    scope: "Primary School Teacher",
    image: "https://i.ibb.co/fdBVvJZ0/photo-6273812502441300493-x-1.jpg"
  },
  {
    title: "B.Sc Nursing",
    category: "Nursing",
    duration: "4 Years",
    eligibility: "10+2 PCB with 45%",
    scope: "Registered Nurse, Healthcare",
    image: "https://i.ibb.co/yFpdHwT6/photo-6278394468041953205-y.jpg"
  },
  {
    title: "BCA",
    category: "Higher Education",
    duration: "3 Years",
    eligibility: "10+2 with Math/CS",
    scope: "Software Developer, IT Sector",
    image: "https://i.ibb.co/YFRSv3sg/photo-6273812502441300440-x.jpg"
  },
  {
    title: "BBA",
    category: "Higher Education",
    duration: "3 Years",
    eligibility: "10+2 Any Stream",
    scope: "Management, HR, Marketing",
    image: "https://i.ibb.co/C5w6PQQy/photo-6273812502441300439-x.jpg"
  },
  {
    title: "GNM",
    category: "Nursing",
    duration: "3 Years",
    eligibility: "10+2 Any Stream",
    scope: "Staff Nurse, Clinical Care",
    image: "https://i.ibb.co/V0t65Y1L/photo-6273812502441300438-x.jpg"
  },
  {
    title: "ANM",
    category: "Nursing",
    duration: "2 Years",
    eligibility: "10+2 Any Stream",
    scope: "Female Health Worker",
    image: "https://i.ibb.co/dJVrg6kD/photo-6273812502441300437-x.jpg"
  },
  {
    title: "B.Lis",
    category: "Higher Education",
    duration: "1 Year",
    eligibility: "Graduation (Any Stream)",
    scope: "Librarian, Information Officer",
    image: "https://i.ibb.co/ccbNVbrs/photo-6273812502441300441-x.jpg"
  }
];

const TESTIMONIALS = [
  {
    name: "Priya Sharma",
    course: "B.Ed",
    review: "The faculty here is exceptional. They focus on practical teaching skills that really prepared me for my career.",
    rating: 5,
    photo: "https://i.pravatar.cc/150?u=priya"
  },
  {
    name: "Manoj Kumar",
    course: "BCA",
    review: "Modern labs and industry-aligned curriculum. I got placed in a top IT firm right after my final semester.",
    rating: 5,
    photo: "https://i.pravatar.cc/150?u=manoj"
  },
  {
    name: "Poonam Kumari",
    course: "GNM",
    review: "The clinical exposure at SHAHEED PRAMOD Nursing Institute is unmatched. We get hands-on training with real patients.",
    rating: 5,
    photo: "https://i.pravatar.cc/150?u=poonam"
  },
  {
    name : 'Uday Kumar',
    course: "B.Sc Nursing",
    review: "The clinical training and hospital exposure are outstanding. The faculty ensures we are ready for real-life medical situations. I'm proud to be a part of this institute.",
    rating: 5,
    photo: "https://i.ibb.co/yBFwtpdf/photo-6278394468041953214-y.jpg"
  },
];

const GALLERY_IMAGES = [
  "https://i.ibb.co/RXxQ0mX/photo-6278394468041953224-y.jpg",
  "https://i.ibb.co/0phddZzH/photo-6278394468041953223-y.jpg",
  "https://i.ibb.co/3929192n/photo-6278394468041953222-y.jpg",
  "https://i.ibb.co/FLvFpFLF/photo-6278394468041953221-y.jpg",
  "https://i.ibb.co/5h6RqMwb/photo-6278394468041953219-x.jpg",
  "https://i.ibb.co/RTP53HVV/photo-6278394468041953218-x.jpg",
  "https://i.ibb.co/jFY5jQm/photo-6278394468041953217-x.jpg",
  "https://i.ibb.co/4nWJDCp4/photo-6266973922368622073-y.jpg",
  "https://i.ibb.co/VYPZ31Bg/photo-6253643297364577725-y.jpg",
  "https://i.ibb.co/S4rRwsBJ/photo-6253643297364577722-y.jpg"
];

const HERO_SLIDES = [
  {
    title: "B.Ed Courses",
    subtitle: "Shape the Minds of Tomorrow",
    image: "https://i.imageupload.app/f8b89fff171fefabefd4.jpeg"
  },
  {
    title: "Nursing Courses",
    subtitle: "Compassion Meets Professionalism",
    image: "https://i.imageupload.app/6df61b3de596a6205061.jpeg"
  },
  {
    title: "BBA/BCA Courses",
    subtitle: "Innovate and Lead in the Digital Age",
    image: "https://i.imageupload.app/b71a5ee9b79f53ae0443.jpeg"
  }
];

// --- Components ---

const AnnouncementBar = () => (
  <div className="bg-royal-blue text-white py-2 overflow-hidden border-b border-gold/30">
    <div className="scrolling-text font-medium">
      पैसा नही बनेगा आपके पढ़ाई में बाधा - Bihar Student Credit Card. • Admissions Open 2026 – Apply Now Today • Limited Seats Available for B.Ed & Nursing • Scholarship Opportunities for Meritorious Students • Visit Campus for Free Career Counseling •
    </div>
  </div>
);

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'glass py-2 shadow-lg' : 'bg-transparent py-4'}`}>
      <div className="container mx-auto px-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img src="https://i.ibb.co/7tLhYn0B/photo-6266973922368622069-y.jpg" alt="SHAHEED PRAMOD Group of Education Logo" className="h-12 w-12 object-contain rounded-full bg-white p-1" referrerPolicy="no-referrer" />
          <div className="hidden sm:block">
            <h1 className={`text-lg font-bold leading-tight ${isScrolled ? 'text-royal-blue' : 'text-white'}`}>
              SHAHEED PRAMOD
            </h1>
            <p className={`text-[10px] font-semibold tracking-widest uppercase ${isScrolled ? 'text-gold' : 'text-gold'}`}>
              Group of Education
            </p>
          </div>
        </div>

        <div className="hidden lg:flex items-center gap-8">
          {['Home', 'Institutions', 'Courses', 'About', 'Gallery', 'Contact'].map((item) => (
            <a 
              key={item} 
              href={`#${item.toLowerCase()}`} 
              className={`text-sm font-semibold uppercase tracking-wider hover:text-gold transition-colors ${isScrolled ? 'text-royal-blue' : 'text-white'}`}
            >
              {item}
            </a>
          ))}
          <Button 
            className="bg-gold hover:bg-gold/90 text-royal-blue font-bold rounded-full px-6"
            onClick={() => document.getElementById('admission')?.scrollIntoView({ behavior: 'smooth' })}
          >
            Apply Now
          </Button>
        </div>

        <button className="lg:hidden text-white" onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
          {isMobileMenuOpen ? <X className={isScrolled ? 'text-royal-blue' : 'text-white'} /> : <Menu className={isScrolled ? 'text-royal-blue' : 'text-white'} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-white border-t border-gray-100 overflow-hidden"
          >
            <div className="flex flex-col p-4 gap-4">
              {['Home', 'Institutions', 'Courses', 'About', 'Gallery', 'Contact'].map((item) => (
                <a 
                  key={item} 
                  href={`#${item.toLowerCase()}`} 
                  className="text-royal-blue font-semibold uppercase tracking-wider"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {item}
                </a>
              ))}
              <Button 
                className="bg-royal-blue text-white w-full"
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  document.getElementById('admission')?.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                Apply Now
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Hero = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % HERO_SLIDES.length);
    }, 3000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section id="home" className="relative h-screen w-full overflow-hidden bg-black">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentSlide}
          initial={{ opacity: 0, scale: 1.1 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 1 }}
          className="absolute inset-0"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-royal-blue/80 to-transparent z-10" />
          <img 
            src={HERO_SLIDES[currentSlide].image} 
            alt="Hero" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </motion.div>
      </AnimatePresence>

      <div className="absolute inset-0 z-20 flex items-center">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ x: -50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="max-w-3xl"
          >
            <Badge className="bg-gold text-royal-blue mb-4 px-4 py-1 text-sm font-bold uppercase tracking-widest">
              AICTE / NCTE Approved
            </Badge>
            <h1 className="text-5xl md:text-7xl font-extrabold text-white mb-4 leading-tight">
              SHAHEED PRAMOD <br />
              <span className="text-gold">Group of Education</span>
            </h1>
            <p className="text-xl md:text-2xl text-white/90 mb-8 font-medium">
              {HERO_SLIDES[currentSlide].subtitle}
            </p>
            <div className="flex flex-wrap gap-4">
              <Button 
                size="lg" 
                className="bg-gold hover:bg-gold/90 text-royal-blue font-bold px-8 py-6 text-lg rounded-full"
                onClick={() => document.getElementById('admission')?.scrollIntoView({ behavior: 'smooth' })}
              >
                Apply Now
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white text-white hover:bg-white hover:text-royal-blue font-bold px-8 py-6 text-lg rounded-full"
                onClick={() => document.getElementById('courses')?.scrollIntoView({ behavior: 'smooth' })}
              >
                Explore all Courses
              </Button>
              <Button 
                size="lg" 
                variant="ghost" 
                className="text-white hover:text-gold font-bold px-8 py-6 text-lg rounded-full flex items-center gap-2"
                onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              >
                <MessageSquare className="w-5 h-5" />
                Free Career Counseling
              </Button>
            </div>
          </motion.div>
        </div>
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-30 flex gap-2">
        {HERO_SLIDES.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrentSlide(i)}
            className={`h-1.5 rounded-full transition-all duration-300 ${currentSlide === i ? 'w-8 bg-gold' : 'w-4 bg-white/50'}`}
          />
        ))}
      </div>
    </section>
  );
};

const Institutions = () => (
  <section id="institutions" className="py-24 bg-gray-50">
    <div className="container mx-auto px-4">
      <div className="text-center mb-16">
        <h2 className="text-4xl md:text-5xl font-bold text-royal-blue mb-4">Our Institutions</h2>
        <div className="h-1.5 w-24 bg-gold mx-auto rounded-full" />
        <p className="mt-6 text-gray-600 max-w-2xl mx-auto text-lg">
          A multi-college integrated platform dedicated to excellence in various professional fields.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        {INSTITUTIONS.map((inst, i) => (
          <motion.div
            key={inst.name}
            whileHover={{ y: -10 }}
            className="group cursor-pointer"
            onClick={() => window.open(inst.link, '_blank')}
          >
            <Card className="overflow-hidden border-none shadow-xl h-full flex flex-col">
              <div className="relative h-64 overflow-hidden">
                <img 
                  src={inst.image} 
                  alt={inst.name} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-4 left-4">
                  <Badge className="bg-royal-blue text-white">{inst.badge}</Badge>
                </div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-6">
                  <Button className="w-full bg-gold text-royal-blue font-bold">Visit Now</Button>
                </div>
              </div>
              <CardContent className="p-6 flex-grow flex flex-col">
                <h3 className="text-xl font-bold text-royal-blue mb-2 group-hover:text-gold transition-colors">
                  {inst.name}
                </h3>
                <p className="text-gray-600 mb-4 flex-grow">{inst.description}</p>
                <div className="flex items-center text-gold font-bold gap-2">
                  Learn More <ArrowRight className="w-4 h-4" />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const Courses = () => (
  <section id="courses" className="py-24 bg-white">
    <div className="container mx-auto px-4">
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
        <div>
          <h2 className="text-4xl md:text-5xl font-bold text-royal-blue mb-4">Academic Programs</h2>
          <div className="h-1.5 w-24 bg-gold rounded-full" />
        </div>
        <p className="text-gray-600 max-w-md text-lg">
          Explore our wide range of professional courses designed to build successful careers.
        </p>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {COURSES.map((course, i) => (
          <motion.div
            key={course.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            viewport={{ once: true }}
          >
            <Card className="overflow-hidden border border-gray-100 hover:border-gold/50 transition-all hover:shadow-2xl group">
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={course.image} 
                  alt={course.title} 
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-royal-blue/20 group-hover:bg-transparent transition-colors" />
                <Badge className="absolute top-4 right-4 bg-white text-royal-blue font-bold">
                  {course.category}
                </Badge>
              </div>
              <CardContent className="p-6">
                <h3 className="text-2xl font-bold text-royal-blue mb-4">{course.title}</h3>
                <div className="space-y-3 mb-6">
                  <div className="flex items-center gap-3 text-sm text-gray-600">
                    <Clock className="w-4 h-4 text-gold" />
                    <span><strong>Duration:</strong> {course.duration}</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-gray-600">
                    <CheckCircle2 className="w-4 h-4 text-gold" />
                    <span><strong>Eligibility:</strong> {course.eligibility}</span>
                  </div>
                  <div className="flex items-center gap-3 text-sm text-gray-600">
                    <GraduationCap className="w-4 h-4 text-gold" />
                    <span><strong>Scope:</strong> {course.scope}</span>
                  </div>
                </div>
                <Button 
                  className="w-full bg-royal-blue hover:bg-royal-blue/90 text-white font-bold group-hover:bg-gold group-hover:text-royal-blue transition-colors"
                  onClick={() => document.getElementById('admission')?.scrollIntoView({ behavior: 'smooth' })}
                >
                  Apply Now
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const DirectorSection = () => (
  <section id="about" className="py-24 bg-royal-blue text-white overflow-hidden relative">
    <div className="absolute top-0 right-0 w-1/3 h-full bg-gold/10 skew-x-12 translate-x-1/2" />
    <div className="container mx-auto px-4 relative z-10">
      <div className="grid md:grid-cols-2 gap-16 items-center">
        <motion.div
          initial={{ x: -100, opacity: 0 }}
          whileInView={{ x: 0, opacity: 1 }}
          viewport={{ once: true }}
          className="relative"
        >
          <div className="absolute -top-4 -left-4 w-24 h-24 border-t-4 border-l-4 border-gold" />
          <div className="absolute -bottom-4 -right-4 w-24 h-24 border-b-4 border-r-4 border-gold" />
          <div className="rounded-2xl overflow-hidden border-4 border-gold/30 shadow-2xl">
            <img 
              src="https://i.ibb.co/2Y35bC0v/photo-6253643297364577727-y.jpg" 
              alt="Director" 
              className="w-full aspect-[4/5] object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="absolute bottom-6 left-6 right-6 glass p-6 rounded-xl border-gold/50">
            <h3 className="text-2xl font-bold text-royal-blue">Shyam Nandan Yadav</h3>
            <p className="text-royal-blue/80 font-bold uppercase tracking-widest text-xs">Director, SHAHEED PRAMOD Group of Education</p>
          </div>
        </motion.div>

        <motion.div
          initial={{ x: 100, opacity: 0 }}
          whileInView={{ x: 0, opacity: 1 }}
          viewport={{ once: true }}
        >
          <h2 className="text-gold text-xl font-bold uppercase tracking-widest mb-4">Message from the Director</h2>
          <h3 className="text-4xl md:text-5xl font-bold mb-8 leading-tight">
            Empowering Future Through <br />
            <span className="text-gold">Quality Education</span>
          </h3>
          <div className="space-y-6 text-lg text-white/80 leading-relaxed">
            <p>
              "Under the visionary leadership of Shri Shyam Nandan Yadav, we are committed to delivering quality education, discipline, and career-focused learning."
            </p>
            <p>
              Our mission is to bridge the gap between academic learning and industry requirements. We believe in nurturing not just professionals, but responsible citizens who can contribute meaningfully to society.
            </p>
            <div className="grid grid-cols-2 gap-8 pt-8">
              <div className="flex items-center gap-4">
                <div className="bg-gold/20 p-3 rounded-lg">
                  <Award className="w-8 h-8 text-gold" />
                </div>
                <div>
                  <h4 className="font-bold text-2xl">15+</h4>
                  <p className="text-sm opacity-70">Years Excellence</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="bg-gold/20 p-3 rounded-lg">
                  <Users className="w-8 h-8 text-gold" />
                </div>
                <div>
                  <h4 className="font-bold text-2xl">5000+</h4>
                  <p className="text-sm opacity-70">Students Trained</p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  </section>
);

const MissionVision = () => (
  <section className="py-24 bg-white">
    <div className="container mx-auto px-4">
      <div className="grid md:grid-cols-2 gap-12">
        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="bg-gray-50 p-12 rounded-3xl border-l-8 border-royal-blue shadow-lg"
        >
          <div className="bg-royal-blue/10 w-16 h-16 rounded-2xl flex items-center justify-center mb-6">
            <ArrowRight className="text-royal-blue w-8 h-8" />
          </div>
          <h3 className="text-3xl font-bold text-royal-blue mb-4">Our Mission</h3>
          <p className="text-xl text-gray-600 leading-relaxed">
            “To provide quality, affordable and skill-based education to every student, ensuring they are ready for the challenges of the modern world.”
          </p>
        </motion.div>

        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="bg-gray-50 p-12 rounded-3xl border-l-8 border-gold shadow-lg"
        >
          <div className="bg-gold/10 w-16 h-16 rounded-2xl flex items-center justify-center mb-6">
            <ArrowRight className="text-gold w-8 h-8" />
          </div>
          <h3 className="text-3xl font-bold text-royal-blue mb-4">Our Vision</h3>
          <p className="text-xl text-gray-600 leading-relaxed">
            “To become a leading educational hub in Bihar, recognized for academic excellence, innovation, and holistic development of students.”
          </p>
        </motion.div>
      </div>
    </div>
  </section>
);

const Facilities = () => (
  <section className="py-24 bg-gray-50">
    <div className="container mx-auto px-4">
      <div className="text-center mb-16">
        <h2 className="text-4xl md:text-5xl font-bold text-royal-blue mb-4">World-Class Facilities</h2>
        <div className="h-1.5 w-24 bg-gold mx-auto rounded-full" />
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
        {[
          { name: "Smart Classrooms", icon: <BookOpen />, img: "https://images.unsplash.com/photo-1577896851231-70ef18881754?auto=format&fit=crop&q=80" },
          { name: "Computer Labs", icon: <Users />, img: "https://images.unsplash.com/photo-1517048676732-d65bc937f952?auto=format&fit=crop&q=80" },
          { name: "Library", icon: <BookOpen />, img: "https://images.unsplash.com/photo-1507842217343-583bb7270b66?auto=format&fit=crop&q=80" },
          { name: "Practical Labs", icon: <Award />, img: "https://images.unsplash.com/photo-1581093458791-9f3c3900df4b?auto=format&fit=crop&q=80" },
          { name: "Hostel", icon: <Clock />, img: "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?auto=format&fit=crop&q=80" }
        ].map((facility, i) => (
          <motion.div
            key={facility.name}
            whileHover={{ y: -5 }}
            className="group"
          >
            <div className="relative h-64 rounded-2xl overflow-hidden mb-4 shadow-md">
              <img 
                src={facility.img} 
                alt={facility.name} 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-royal-blue/40 group-hover:bg-royal-blue/20 transition-colors flex items-center justify-center">
                <div className="text-white text-center p-4">
                  <div className="mb-2 flex justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    {React.cloneElement(facility.icon as React.ReactElement, { className: "w-8 h-8" })}
                  </div>
                  <h4 className="font-bold text-lg">{facility.name}</h4>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const Testimonials = () => {
  return (
    <section className="py-24 bg-white overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-royal-blue mb-4">Student Testimonials</h2>
          <div className="h-1.5 w-24 bg-gold mx-auto rounded-full" />
        </div>

        <Carousel
          opts={{
            align: "start",
            loop: true,
          }}
          className="w-full max-w-5xl mx-auto"
        >
          <CarouselContent>
            {TESTIMONIALS.map((t, i) => (
              <CarouselItem key={i} className="md:basis-1/2 lg:basis-1/3 p-4">
                <Card className="h-full border-none shadow-lg bg-gray-50">
                  <CardContent className="p-8">
                    <div className="flex gap-1 mb-6">
                      {[...Array(t.rating)].map((_, i) => (
                        <Star key={i} className="w-5 h-5 fill-gold text-gold" />
                      ))}
                    </div>
                    <p className="text-gray-600 italic mb-8">"{t.review}"</p>
                    <div className="flex items-center gap-4">
                      <img src={t.photo} alt={t.name} className="w-12 h-12 rounded-full border-2 border-gold" />
                      <div>
                        <h4 className="font-bold text-royal-blue">{t.name}</h4>
                        <p className="text-xs font-bold text-gold uppercase tracking-widest">{t.course}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </CarouselItem>
            ))}
          </CarouselContent>
          <div className="hidden md:block">
            <CarouselPrevious className="bg-royal-blue text-white hover:bg-gold hover:text-royal-blue border-none" />
            <CarouselNext className="bg-royal-blue text-white hover:bg-gold hover:text-royal-blue border-none" />
          </div>
        </Carousel>
      </div>
    </section>
  );
};

const AdmissionForm = () => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    dob: '',
    gender: '',
    course: '',
    tenthMarks: '',
    twelfthMarks: '',
    graduationMarks: '',
    address: '',
    photoName: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const message = `*Admission Registration Form*\n\n` +
      `*Personal Details:*\n` +
      `Name: ${formData.name}\n` +
      `Phone: ${formData.phone}\n` +
      `Email: ${formData.email}\n` +
      `DOB: ${formData.dob}\n` +
      `Gender: ${formData.gender}\n\n` +
      `*Academic Details:*\n` +
      `10th Marks: ${formData.tenthMarks}%\n` +
      `12th Marks: ${formData.twelfthMarks}%\n` +
      `Graduation: ${formData.graduationMarks || 'N/A'}\n\n` +
      `*Course Applied:*\n` +
      `${formData.course}\n\n` +
      `*Address:*\n` +
      `${formData.address}\n\n` +
      `*Photo Uploaded:* ${formData.photoName ? 'Yes (' + formData.photoName + ')' : 'No'}`;
    
    window.open(`https://wa.me/918877612728?text=${encodeURIComponent(message)}`, '_blank');
  };

  return (
    <section id="admission" className="py-24 bg-royal-blue relative overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <img src="input_file_11.png" alt="bg" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
      </div>
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto bg-white rounded-3xl shadow-2xl overflow-hidden grid md:grid-cols-2">
          <div className="p-12 bg-gold text-royal-blue flex flex-col justify-center">
            <h2 className="text-4xl font-bold mb-6">Start Your Journey Today</h2>
            <p className="text-lg mb-8 opacity-90">
              Fill out the form to get a call back from our expert career counselors. We'll help you choose the right path for your future.
            </p>
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <div className="bg-royal-blue/10 p-2 rounded-full"><Phone className="w-5 h-5" /></div>
                <span className="font-bold">8877612728, 0621 2273439</span>
              </div>
              <div className="flex items-center gap-4">
                <div className="bg-royal-blue/10 p-2 rounded-full"><Mail className="w-5 h-5" /></div>
                <span className="font-bold">shaheedpramodb.ed@gmail.com</span>
              </div>
            </div>
          </div>
          <div className="p-12">
            <h3 className="text-2xl font-bold text-royal-blue mb-8">Student Registration</h3>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">Full Name</label>
                  <Input 
                    placeholder="Enter your name" 
                    className="rounded-xl border-gray-200" 
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">Phone Number</label>
                  <Input 
                    placeholder="Enter mobile number" 
                    className="rounded-xl border-gray-200" 
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">Email Address</label>
                  <Input 
                    type="email"
                    placeholder="Enter email" 
                    className="rounded-xl border-gray-200" 
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({...formData, email: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">Date of Birth</label>
                  <Input 
                    type="date"
                    className="rounded-xl border-gray-200" 
                    required
                    value={formData.dob}
                    onChange={(e) => setFormData({...formData, dob: e.target.value})}
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">Gender</label>
                  <Select onValueChange={(v) => setFormData({...formData, gender: v})}>
                    <SelectTrigger className="rounded-xl border-gray-200">
                      <SelectValue placeholder="Select Gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Male">Male</SelectItem>
                      <SelectItem value="Female">Female</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-gray-700">Select Course</label>
                  <Select onValueChange={(v) => setFormData({...formData, course: v})}>
                    <SelectTrigger className="rounded-xl border-gray-200">
                      <SelectValue placeholder="Choose a course" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="B.Ed">B.Ed</SelectItem>
                      <SelectItem value="D.El.Ed">D.El.Ed</SelectItem>
                      <SelectItem value="B.Sc Nursing">B.Sc Nursing</SelectItem>
                      <SelectItem value="GNM">GNM</SelectItem>
                      <SelectItem value="ANM">ANM</SelectItem>
                      <SelectItem value="BCA">BCA</SelectItem>
                      <SelectItem value="BBA">BBA</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="border-t border-gray-100 pt-6">
                <h4 className="text-sm font-bold text-royal-blue mb-4 uppercase tracking-wider">Academic Details</h4>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-500">10th (%)</label>
                    <Input 
                      placeholder="e.g. 85" 
                      className="rounded-xl border-gray-200" 
                      required
                      value={formData.tenthMarks}
                      onChange={(e) => setFormData({...formData, tenthMarks: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-500">12th (%)</label>
                    <Input 
                      placeholder="e.g. 82" 
                      className="rounded-xl border-gray-200" 
                      required
                      value={formData.twelfthMarks}
                      onChange={(e) => setFormData({...formData, twelfthMarks: e.target.value})}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-500">Graduation (%)</label>
                    <Input 
                      placeholder="Optional" 
                      className="rounded-xl border-gray-200" 
                      value={formData.graduationMarks}
                      onChange={(e) => setFormData({...formData, graduationMarks: e.target.value})}
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700">Upload Passport Photo</label>
                <div className="relative">
                  <Input 
                    type="file"
                    accept="image/*"
                    className="rounded-xl border-gray-200 cursor-pointer pt-2" 
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) setFormData({...formData, photoName: file.name});
                    }}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-700">Permanent Address</label>
                <Textarea 
                  placeholder="Full address with PIN code" 
                  className="rounded-xl border-gray-200 h-24" 
                  required
                  value={formData.address}
                  onChange={(e) => setFormData({...formData, address: e.target.value})}
                />
              </div>

              <Button type="submit" className="w-full bg-royal-blue hover:bg-gold hover:text-royal-blue text-white font-bold py-6 rounded-xl transition-all shadow-lg">
                Complete Registration
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

const Gallery = () => {
  return (
    <section id="gallery" className="py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center mb-16">
          <div className="text-center md:text-left mb-8 md:mb-0">
            <h2 className="text-4xl md:text-5xl font-bold text-royal-blue mb-4">Campus Gallery</h2>
            <div className="h-1.5 w-24 bg-gold rounded-full" />
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {GALLERY_IMAGES.map((img, i) => (
            <div key={i}>
              <Dialog>
                <DialogTrigger
                  nativeButton={false}
                  render={
                    <motion.div 
                      whileHover={{ scale: 1.05 }}
                      className="cursor-pointer rounded-xl overflow-hidden h-64 shadow-lg group relative"
                    >
                      <img 
                        src={img} 
                        alt={`Gallery ${i}`} 
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <ArrowRight className="text-white w-8 h-8" />
                      </div>
                    </motion.div>
                  }
                />
                <DialogContent className="max-w-4xl p-0 overflow-hidden bg-transparent border-none">
                  <img src={img} alt="Preview" className="w-full h-auto rounded-xl" referrerPolicy="no-referrer" />
                </DialogContent>
              </Dialog>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Contact = () => (
  <section id="contact" className="py-24 bg-gray-50">
    <div className="container mx-auto px-4">
      <div className="grid lg:grid-cols-2 gap-16">
        <div>
          <h2 className="text-4xl font-bold text-royal-blue mb-8">Get In Touch</h2>
          <div className="space-y-8">
            <div className="flex gap-6">
              <div className="bg-white p-4 rounded-2xl shadow-md text-gold h-fit">
                <MapPin className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-xl text-royal-blue mb-2">Our Address</h4>
                <p className="text-gray-600">Susta Madhopur, Muzaffarpur, Bihar - 842002</p>
              </div>
            </div>
            <div className="flex gap-6">
              <div className="bg-white p-4 rounded-2xl shadow-md text-gold h-fit">
                <Phone className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-xl text-royal-blue mb-2">Call Us</h4>
                <p className="text-gray-600">0621 2273439, 8877612728, 8969094175</p>
              </div>
            </div>
            <div className="flex gap-6">
              <div className="bg-white p-4 rounded-2xl shadow-md text-gold h-fit">
                <Mail className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-xl text-royal-blue mb-2">Email Us</h4>
                <p className="text-gray-600">shaheedpramodb.ed@gmail.com</p>
              </div>
            </div>
          </div>

          <div className="mt-12 flex gap-4">
            {[Facebook, Instagram, Twitter, Youtube].map((Icon, i) => (
              <a key={i} href="#" className="bg-royal-blue text-white p-3 rounded-full hover:bg-gold hover:text-royal-blue transition-all">
                <Icon className="w-5 h-5" />
              </a>
            ))}
          </div>
        </div>

        <div className="rounded-3xl overflow-hidden shadow-2xl border-4 border-white h-[450px]">
          <iframe 
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3581.428581005128!2d85.384298!3d26.080355!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39ed112233445566%3A0x1122334455667788!2sSusta%20Madhopur%2C%20Muzaffarpur%2C%20Bihar!5e0!3m2!1sen!2sin!4v1712710000000!5m2!1sen!2sin" 
            width="100%" 
            height="100%" 
            style={{ border: 0 }} 
            allowFullScreen 
            loading="lazy" 
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </div>
    </div>
  </section>
);

const Footer = () => (
  <footer className="bg-royal-blue text-white pt-24 pb-12">
    <div className="container mx-auto px-4">
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
        <div className="col-span-1 lg:col-span-1">
          <div className="flex items-center gap-3 mb-6">
            <img src="https://i.ibb.co/7tLhYn0B/photo-6266973922368622069-y.jpg" alt="SHAHEED PRAMOD Group of Education Logo" className="h-12 w-12 object-contain rounded-full bg-white p-1" referrerPolicy="no-referrer" />
            <div>
              <h2 className="text-xl font-bold">SHAHEED PRAMOD</h2>
              <p className="text-[10px] text-gold font-bold uppercase tracking-widest">Group of Education</p>
            </div>
          </div>
          <p className="text-white/70 leading-relaxed mb-6">
            Empowering the next generation of professionals through quality education, modern facilities, and expert guidance.
          </p>
          <div className="flex gap-4">
            <img src="https://upload.wikimedia.org/wikipedia/en/thumb/5/58/NCTE_logo.png/220px-NCTE_logo.png" alt="NCTE" className="h-10 opacity-50 grayscale hover:grayscale-0 transition-all" />
            <img src="https://upload.wikimedia.org/wikipedia/en/thumb/d/d2/Indian_Nursing_Council_logo.png/220px-Indian_Nursing_Council_logo.png" alt="INC" className="h-10 opacity-50 grayscale hover:grayscale-0 transition-all" />
          </div>
          <div className="flex items-center gap-4 mt-6">
            <a href="https://www.facebook.com/share/1BQadJ64X2/" target="_blank" rel="noreferrer" className="text-white/50 hover:text-[#1877F2] transition-colors bg-white/10 p-2 rounded-full hover:bg-white">
              <Facebook className="w-5 h-5" />
            </a>
            <a href="https://www.instagram.com/shaheedpramodhighereducation?igsh=MXZzYWhlMmh2Zmg3MQ==" target="_blank" rel="noreferrer" className="text-white/50 hover:text-[#E1306C] transition-colors bg-white/10 p-2 rounded-full hover:bg-white">
              <Instagram className="w-5 h-5" />
            </a>
            <a href="https://youtube.com/@shahidpramodgroupofeducation?si=_NuRHU1CCGUr0fMN" target="_blank" rel="noreferrer" className="text-white/50 hover:text-[#FF0000] transition-colors bg-white/10 p-2 rounded-full hover:bg-white">
              <Youtube className="w-5 h-5" />
            </a>
          </div>
        </div>

        <div>
          <h4 className="text-xl font-bold mb-6 border-b-2 border-gold w-fit pb-2">Quick Links</h4>
          <ul className="space-y-4 text-white/70">
            {['Home', 'About Us', 'Institutions', 'Academic Courses', 'Admission', 'Gallery', 'Contact'].map(item => (
              <li key={item}><a href="#" className="hover:text-gold transition-colors flex items-center gap-2"><ChevronRight className="w-4 h-4" /> {item}</a></li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="text-xl font-bold mb-6 border-b-2 border-gold w-fit pb-2">Our Colleges</h4>
          <ul className="space-y-4 text-white/70">
            <li><a href="https://shaheedpramod.in" target="_blank" className="hover:text-gold transition-colors flex items-center gap-2"><ExternalLink className="w-4 h-4" /> SHAHEED PRAMOD B.Ed College</a></li>
            <li><a href="https://shaheedpramod.in" target="_blank" className="hover:text-gold transition-colors flex items-center gap-2"><ExternalLink className="w-4 h-4" /> SHAHEED PRAMOD Higher Education</a></li>
            <li><a href="https://spnursing.in" target="_blank" className="hover:text-gold transition-colors flex items-center gap-2"><ExternalLink className="w-4 h-4" /> SHAHEED PRAMOD Nursing Institute</a></li>
          </ul>
        </div>

        <div>
          <h4 className="text-xl font-bold mb-6 border-b-2 border-gold w-fit pb-2">Newsletter</h4>
          <p className="text-white/70 mb-4">Subscribe to get latest updates on admissions and events.</p>
          <div className="flex gap-2">
            <Input placeholder="Email Address" className="bg-white/10 border-white/20 text-white placeholder:text-white/40 rounded-xl" />
            <Button className="bg-gold text-royal-blue font-bold rounded-xl">Join</Button>
          </div>
        </div>
      </div>

      <div className="border-t border-white/10 pt-8 text-center text-white/50 text-sm">
        <p>© 2026 SHAHEED PRAMOD Group of Education. All Rights Reserved. | Designed for Excellence</p>
      </div>
    </div>
  </footer>
);

const FloatingCTA = () => {
  const [openMenu, setOpenMenu] = useState<'whatsapp' | 'call' | null>(null);

  const CONTACTS = [
    { name: 'B.Ed College', phone: '918877612728', wa: '918877612728' },
    { name: 'Higher Education', phone: '919955657050', wa: '919955657050' },
    { name: 'Nursing Institute', phone: '916202792816', wa: '916202792816' },
  ];

  return (
    <div className="fixed bottom-8 right-8 z-50 flex flex-col gap-4">
      <AnimatePresence>
        {openMenu && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="absolute bottom-full right-0 mb-4 bg-white rounded-2xl shadow-2xl p-4 w-64 border border-gray-100"
          >
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-bold text-royal-blue text-sm">
                {openMenu === 'whatsapp' ? 'Chat on WhatsApp' : 'Call Us'}
              </h3>
              <button onClick={() => setOpenMenu(null)} className="text-gray-400 hover:text-gray-600">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="flex flex-col gap-2">
              {CONTACTS.map((contact) => (
                <a
                  key={contact.name}
                  href={openMenu === 'whatsapp' ? `https://wa.me/${contact.wa}` : `tel:+${contact.phone}`}
                  target="_blank"
                  rel="noreferrer"
                  className={`flex items-center gap-3 p-3 rounded-xl transition-colors ${
                    openMenu === 'whatsapp' 
                      ? 'bg-green-50 hover:bg-green-100 text-green-700' 
                      : 'bg-blue-50 hover:bg-blue-100 text-royal-blue'
                  }`}
                  onClick={() => setOpenMenu(null)}
                >
                  {openMenu === 'whatsapp' ? <MessageSquare className="w-4 h-4" /> : <Phone className="w-4 h-4" />}
                  <div className="flex flex-col">
                    <span className="text-xs font-bold">{contact.name}</span>
                    <span className="text-[10px] opacity-80">+{contact.phone}</span>
                  </div>
                </a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <button 
        onClick={() => setOpenMenu(openMenu === 'whatsapp' ? null : 'whatsapp')}
        className="bg-green-500 text-white p-4 rounded-full shadow-2xl flex items-center justify-center group relative hover:scale-110 transition-transform"
      >
        <MessageSquare className="w-6 h-6" />
        <span className="absolute right-full mr-4 bg-white text-green-500 font-bold px-4 py-2 rounded-xl shadow-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
          WhatsApp Us
        </span>
      </button>
      
      <button 
        onClick={() => setOpenMenu(openMenu === 'call' ? null : 'call')}
        className="bg-royal-blue text-white p-4 rounded-full shadow-2xl flex items-center justify-center group relative hover:scale-110 transition-transform"
      >
        <Phone className="w-6 h-6" />
        <span className="absolute right-full mr-4 bg-white text-royal-blue font-bold px-4 py-2 rounded-xl shadow-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
          Call Now
        </span>
      </button>

      <a 
        href="#admission" 
        className="bg-gold text-royal-blue p-4 rounded-full shadow-2xl flex items-center justify-center group relative hover:scale-110 transition-transform"
      >
        <GraduationCap className="w-6 h-6" />
        <span className="absolute right-full mr-4 bg-white text-gold font-bold px-4 py-2 rounded-xl shadow-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
          Apply Now
        </span>
      </a>
    </div>
  );
};

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="fixed top-0 left-0 right-0 z-50">
        <AnnouncementBar />
        <Navbar />
      </header>
      
      <main className="flex-grow">
        <Hero />
        <Institutions />
        <Courses />
        <DirectorSection />
        <MissionVision />
        <Facilities />
        <Testimonials />
        <AdmissionForm />
        <Gallery />
        <Contact />
      </main>

      <Footer />
      <FloatingCTA />
    </div>
  );
}
