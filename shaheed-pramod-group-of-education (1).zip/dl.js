import fs from 'fs';
async function run() {
  const r = await fetch('https://i.ibb.co/G3sCGcXv/photo-6273812502441300436-x.jpg');
  const buffer = await r.arrayBuffer();
  fs.writeFileSync('436.jpg', Buffer.from(buffer));
  console.log("done");
}
run();
