import Tesseract from 'tesseract.js';

async function mapImage() {
  try {
    const result = await Tesseract.recognize("https://i.ibb.co/G3sCGcXv/photo-6273812502441300436-x.jpg", 'eng');
    console.log(result.data.text);
  } catch (e) {}
}

mapImage();
