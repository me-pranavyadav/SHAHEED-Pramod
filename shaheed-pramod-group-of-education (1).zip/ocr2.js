import Tesseract from 'tesseract.js';
import fs from 'fs';

async function mapImages() {
  const images = {
    "1": "https://i.ibb.co/ccbNVbrs/photo-6273812502441300441-x.jpg",
    "2": "https://i.ibb.co/YFRSv3sg/photo-6273812502441300440-x.jpg",
    "3": "https://i.ibb.co/C5w6PQQy/photo-6273812502441300439-x.jpg",
    "4": "https://i.ibb.co/V0t65Y1L/photo-6273812502441300438-x.jpg",
    "5": "https://i.ibb.co/dJVrg6kD/photo-6273812502441300437-x.jpg",
    "6": "https://i.ibb.co/G3sCGcXv/photo-6273812502441300436-x.jpg"
  };

  try {
    const result = await Tesseract.recognize(images["6"], 'eng');
    console.log(result.data.text);
  } catch (e) {}
}

mapImages();
