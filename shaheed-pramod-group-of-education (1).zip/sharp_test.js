import sharp from 'sharp';

async function run() {
  const metadata = await sharp('436.jpg').metadata();
  console.log(metadata);
}
run();
