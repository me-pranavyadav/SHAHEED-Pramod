import { GoogleGenAI } from "@google/genai";

async function describeImages() {
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  const urls = [
    'https://i.ibb.co/ccbNVbrs/photo-6273812502441300441-x.jpg',
    'https://i.ibb.co/YFRSv3sg/photo-6273812502441300440-x.jpg',
    'https://i.ibb.co/C5w6PQQy/photo-6273812502441300439-x.jpg',
    'https://i.ibb.co/V0t65Y1L/photo-6273812502441300438-x.jpg',
    'https://i.ibb.co/dJVrg6kD/photo-6273812502441300437-x.jpg',
    'https://i.ibb.co/G3sCGcXv/photo-6273812502441300436-x.jpg'
  ];
  
  for (const url of urls) {
    try {
      const response = await fetch(url);
      const arrayBuffer = await response.arrayBuffer();
      const buffer = Buffer.from(arrayBuffer);
      const base64String = buffer.toString('base64');
      
      const res = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [
          {
            role: "user",
            parts: [
              {
                inlineData: {
                  data: base64String,
                  mimeType: "image/jpeg"
                }
              },
              { text: "Read the main text or course name on this image. Keep it under 5 words." }
            ]
          }
        ]
      });
      console.log(url, "=>", res.text.trim());
    } catch(e) {
      console.log(url, "Error:", e.message);
    }
  }
}

describeImages();
